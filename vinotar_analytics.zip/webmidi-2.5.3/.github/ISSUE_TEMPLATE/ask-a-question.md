---
name: Ask a question
about: This is to ask a usage, support or general question
title: ''
labels: ''
assignees: ''

---

**Questions should be submitted to the Forum**

All questions should be submitted to the **Questions & Support** section of the WebMidi.js Forum: 

https://webmidijs.org/forum/

This opens up the question to the community while reserving GitHub strictly for bugs and issues.

Thank you.
