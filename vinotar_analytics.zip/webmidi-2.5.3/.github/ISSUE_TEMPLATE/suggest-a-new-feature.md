---
name: Suggest a new feature
about: This is to suggest a new feature or improvement
title: ''
labels: ''
assignees: ''

---

**Enhancement proposals should be submitted in the Forum**

To submit a new feature or improvement request, please post it to the **Enhancement Proposals** section of the WebMidi.js Forum: 

https://webmidijs.org/forum/

This allows the feature request to be discussed with the community while reserving GitHub strictly for bugs and issues.

Thank you.
