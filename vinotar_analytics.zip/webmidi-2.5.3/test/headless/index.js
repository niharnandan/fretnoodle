// This is the entry-point for the tests
require("./virtual-midi.test.js");
require("./webmidi.test.js");
require("./input.test.js");
require("./output.test.js");
require("./platform.test.js");